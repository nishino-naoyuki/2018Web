/**
 *
 */
package dbkadai3.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * @author nishino
 *
 */
public class DBModel {

	public boolean getMailList(String user,String password){
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		boolean result = false;

		try{
			///////////////////////////////////
			//DBの接続
			Class.forName("com.mysql.cj.jdbc.Driver");

			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/webtestdb?characterEncoding=UTF-8&serverTimezone=JST",
					"root","password");

			///////////////////////////////////
			//SELECT文の発行
			stmt = con.prepareStatement("SELECT * FROM user_tbl WHERE mail=? AND password=?");

			stmt.setString(1, user);
			stmt.setString(2, password);
			rs = stmt.executeQuery();
			System.out.println(stmt);

			///////////////////////////////////
			//DBから値を取得
			while( rs.next() ){
				result = true;
			}

		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		finally {
			if(con!=null) {
				try {
					con.close();
				}
				catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return result;
	}


	/**
	 * 指定された情報をユーザーテーブルに挿入する
	 *
	 * @param mail
	 * @param password
	 * @param name
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public void insert(String mail,String password,String name)
						throws ClassNotFoundException, SQLException{

		Connection con = null;
		PreparedStatement stmt = null;

		try{
			///////////////////////////////////
			//DBの接続
			Class.forName("com.mysql.cj.jdbc.Driver");

			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/webtestdb?characterEncoding=UTF-8&serverTimezone=JST",
					"root","password");

			///////////////////////////////////
			//INSERT文の発行
			stmt = con.prepareStatement("INSERT INTO user_tbl(mail,password,name) VALUES(?,?,?)");

			stmt.setString(1, mail);
			stmt.setString(2, password);
			stmt.setString(3, name);
			stmt.executeUpdate();

		}catch(ClassNotFoundException e) {
			e.printStackTrace();
			throw e;
		}catch(SQLException e) {
			e.printStackTrace();
			throw e;
		}finally {
			if(con!=null) {
				try {
					con.close();
				}
				catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}

	}

	/**
	 * パスワード更新処理
	 *
	 * @param mail
	 * @param password
	 * @throws ClassNotFoundException
	 * @throws SQLException
	 */
	public int update(String mail,String password)
						throws ClassNotFoundException, SQLException{

		Connection con = null;
		PreparedStatement stmt = null;

		int num = 0;
		try{
			///////////////////////////////////
			//DBの接続
			Class.forName("com.mysql.cj.jdbc.Driver");

			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/webtestdb?characterEncoding=UTF-8&serverTimezone=JST",
					"root","password");

			///////////////////////////////////
			//UPDATE文の発行
			stmt = con.prepareStatement("UPDATE user_tbl SET password=? WHERE mail=?");

			stmt.setString(1, password);
			stmt.setString(2, mail);
			num = stmt.executeUpdate();

		}catch(ClassNotFoundException e) {
			e.printStackTrace();
			throw e;
		}catch(SQLException e) {
			e.printStackTrace();
			throw e;
		}finally {
			if(con!=null) {
				try {
					con.close();
				}
				catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return num;

	}
}
