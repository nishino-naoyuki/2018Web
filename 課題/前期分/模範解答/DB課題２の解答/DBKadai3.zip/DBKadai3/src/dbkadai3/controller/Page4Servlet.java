/**
 *
 */
package dbkadai3.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dbkadai3.model.DBModel;

/**
 * @author nishino
 *
 */
@WebServlet("/page4")
public class Page4Servlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest request,HttpServletResponse response)
												throws ServletException,IOException{


		///////////////////////////////////////
		//JSPから値を取得する
		String mail = request.getParameter("mail");
		String password = request.getParameter("password");
		String name = request.getParameter("name");

		///////////////////////////////////////
		//JSPで入力した情報をデータベースへセット
		String message = "";
		try {
			DBModel dbModel = new DBModel();

			dbModel.insert(mail, password, name);

			message = "登録に成功しました！";
		} catch (ClassNotFoundException e) {
			message = "エラーが発生しました";
		} catch (SQLException e) {
			message = "エラーが発生しました";
		}

		///////////////////////////////////////
		//リクエストスコープにメッセージをセット
		request.setAttribute("message", message);

		///////////////////////////////////////
		//画面遷移
		RequestDispatcher dis=request.getRequestDispatcher("WEB-INF/jsp/page4.jsp");
		dis.forward(request, response);
	}
}
