package dbkadai2.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DBModel {

	public boolean getMailList(String user,String password){
		List<String> list = new ArrayList<String>();

		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		boolean result = false;
		try{
			///////////////////////////////////
			//DBの接続
			Class.forName("com.mysql.cj.jdbc.Driver");

			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/webtestdb?characterEncoding=UTF-8&serverTimezone=JST",
					"root","password");

			///////////////////////////////////
			//SELECT文の発行
			stmt = con.prepareStatement("SELECT * FROM user_tbl WHERE mail=? AND password=?");

			stmt.setString(1, user);
			stmt.setString(2, password);
			rs = stmt.executeQuery();
			System.out.println(stmt);

			///////////////////////////////////
			//DBから値を取得
			while( rs.next() ){
				result = true;
			}

		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		finally {
			if(con!=null) {
				try {
					con.close();
				}
				catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return result;
	}
}
