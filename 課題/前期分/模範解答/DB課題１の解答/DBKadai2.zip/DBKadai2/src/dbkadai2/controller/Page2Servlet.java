package dbkadai2.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dbkadai2.model.DBModel;

@WebServlet("/page2")
public class Page2Servlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
							throws ServletException, IOException {

		/////////////////////////
		//JSPから値取得
		String user = request.getParameter("user");
		String password = request.getParameter("password");

		/////////////////////////
		//JSPから値取得
		DBModel dbModel = new DBModel();

		boolean result = dbModel.getMailList(user, password);

		///////////////////////
		//ログインに成功したかどうかを確認する
		String msg = "";
		if( result ){
			//ログイン成功
			msg = "ログイン成功";
		}else{
			//ログインに失敗
			msg = "ログイン失敗";
		}

		////////////////////////
		//リクエストにセットする
		request.setAttribute("msg", msg);

		/////////////////////////
		//画面転送
		RequestDispatcher dispacher = request.getRequestDispatcher("WEB-INF/jsp/page2.jsp");
		dispacher.forward(request, response);
	}
}
