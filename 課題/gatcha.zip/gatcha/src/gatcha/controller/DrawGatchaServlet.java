package gatcha.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import gatcha.beans.LoginInfoBeans;

@WebServlet("/draw")
public class DrawGatchaServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		////////////////////////////////////
		//セッションからログイン情報を取得する
		HttpSession session = request.getSession();

		LoginInfoBeans loginInfo = (LoginInfoBeans)session.getAttribute("loginInfo");

		////////////////////////////////////
		//ガチャを引く（モデルのメソッドを呼び出す）

		///////////////////////////////////
		//ガチャを引いた結果をエススコープへセット

		RequestDispatcher dispatcher = request.getRequestDispatcher("WEB-INF/jsp/result.jsp");
		dispatcher.forward(request, response);
	}
}
