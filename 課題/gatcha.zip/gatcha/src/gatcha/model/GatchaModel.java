package gatcha.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.naming.InitialContext;

import gatcha.beans.GatchaBeans;
import gatcha.beans.GatchaListBeans;
import gatcha.beans.LoginInfoBeans;

/**
 * ガチャに関するモデル
 * @author nishino
 *
 */
public class GatchaModel {

	/**
	 * ランダムにガチャを引く
	 *
	 * @return ガチャビーンズ
	 */
	public GatchaBeans getRandom(LoginInfoBeans loginBeans){

		///////////////////////////////
		//0～999の乱数を取得
		Random rand = new Random();

		int value = rand.nextInt(1000);

		int[] reaList =
			{0,1,2,3,4,5};
		String[] reaString =
			{"めちゃめちゃレア","かなりレア","レア","ちょっとレア","すこしレア","普通"};
		String[] imgPath =
			{"dragon.png","hippogriff.png","fox.png","hastur.png","kaiju.png","cat.png"};

		////////////////////////////
		//ビーンズのインスタンス生成
		GatchaBeans gatcha = new GatchaBeans();

		///////////////////////////
		//レア判定
		int reality = 0;


		////////////////////////////
		//ビーンズに設定
		gatcha.setReality(reaList[reality]);
		gatcha.setImg(imgPath[reality]);
		gatcha.setReaString(reaString[reality]);

		////////////////////////////////
		//履歴テーブルに書き込む
		Connection con = null;
		PreparedStatement stmt = null;
		InitialContext context = null;

		try{
			///////////////////////////////////
			//DBの接続（コネクションプーリングから接続を取得）

			///////////////////////////////////
			//SELECT文の発行

//		}catch(NamingException e) {
//			//エラー発生した場合にコンソールにログを出力する
//			e.printStackTrace();
//		}catch(SQLException e) {
//			//エラー発生した場合にコンソールにログを出力する
//			e.printStackTrace();
		}
		finally {
			//接続（コネクション）を閉じる
			if(con!=null) {
				try {
					con.close();
				}
				catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return gatcha;
	}

	/**
	 * 履歴のリストを取得する
	 * （日付の降順）
	 *
	 * @return 履歴リスト
	 */
	public List<GatchaListBeans> getList(){
		List<GatchaListBeans> list = new ArrayList<GatchaListBeans>();

		Connection con = null;
		PreparedStatement stmt = null;
		InitialContext context = null;
		ResultSet rs = null;

		try{
			///////////////////////////////////
			//DBの接続（コネクションプーリングから接続を取得）

			///////////////////////////////////
			//SELECT文の発行

			/////////////////////////////////////
			//値の取得
			while(rs.next()){
				//////////////////////////////////
				//ビーンズのリストに格納する
				GatchaListBeans beans = new GatchaListBeans();

				beans.setImg(rs.getString("img"));
				beans.setReality(rs.getInt("reality"));
				beans.setInsertDate(rs.getTimestamp("insertdate"));

				list.add(beans);
			}

//		}catch(NamingException e) {
//			//エラー発生した場合にコンソールにログを出力する
//			e.printStackTrace();
		}catch(SQLException e) {
			//エラー発生した場合にコンソールにログを出力する
			e.printStackTrace();
		}
		finally {
			//接続（コネクション）を閉じる
			if(con!=null) {
				try {
					con.close();
				}
				catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return list;
	}
}
