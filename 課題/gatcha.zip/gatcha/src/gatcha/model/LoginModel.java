package gatcha.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import gatcha.beans.LoginInfoBeans;

public class LoginModel {

	/**
	 * ログイン処理を行う
	 * 引数でもらったmailとパスワード
	 *
	 * @param mail
	 * @param password
	 * @return
	 */
	public LoginInfoBeans login(String mail,String password){
		LoginInfoBeans loginInfo = null;

		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		InitialContext context = null;

		try{
			///////////////////////////////////
			//DBの接続
			String resourceName = "jdbc/MySQL";
			String jndi = "java:comp/env/"+resourceName;

			context = new InitialContext();

			DataSource dataSource = (DataSource) context.lookup(jndi);

			con = dataSource.getConnection();


			///////////////////////////////////
			//SELECT文の発行
			stmt = con.prepareStatement("SELECT * FROM user_tbl WHERE mail=? AND password=?");

			stmt.setString(1, mail);
			stmt.setString(2, password);
			rs = stmt.executeQuery();

			///////////////////////////////////
			//DBから値を取得
			while( rs.next() ){
				loginInfo = new LoginInfoBeans();

				loginInfo.setMail(rs.getString("mail"));
				loginInfo.setName(rs.getString("name"));
			}

		}catch(NamingException e) {
			//エラー発生した場合にコンソールにログを出力する
			e.printStackTrace();
		}catch(SQLException e) {
			//エラー発生した場合にコンソールにログを出力する
			e.printStackTrace();
		}
		finally {
			//接続（コネクション）を閉じる
			if(con!=null) {
				try {
					con.close();
				}
				catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}


		return loginInfo;
	}
}
