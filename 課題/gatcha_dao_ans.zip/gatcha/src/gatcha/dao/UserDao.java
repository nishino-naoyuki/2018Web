package gatcha.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import gatcha.beans.LoginInfoBeans;

public class UserDao extends DaoBase {

	/**
	 * ユーザーDBよりユーザー情報を取得する
	 * （ログイン処理と等価）
	 *
	 * @param mail　メールアドレス
	 * @param password　パスワード
	 * @return
	 */
	public LoginInfoBeans getBy(String mail,String password){

		if( con == null){
			//接続していない場合はエラーとする
			return null;
		}
		LoginInfoBeans loginInfo = null;

		PreparedStatement stmt = null;
		ResultSet rs = null;

		try{

			///////////////////////////////////
			//SELECT文の発行
			stmt = con.prepareStatement("SELECT * FROM user_tbl WHERE mail=? AND password=?");

			stmt.setString(1, mail);
			stmt.setString(2, password);
			rs = stmt.executeQuery();

			///////////////////////////////////
			//DBから値を取得
			while( rs.next() ){
				loginInfo = new LoginInfoBeans();

				loginInfo.setMail(rs.getString("mail"));
				loginInfo.setName(rs.getString("name"));
			}

		}catch(SQLException e) {
			//エラー発生した場合にコンソールにログを出力する
			e.printStackTrace();
		}
		finally {
	    	try {
		        // 接続を閉じる
	        	if( rs != null ){
					rs.close();
	        	}
	        	if( stmt != null ){
	        		stmt.close();
	        	}
			} catch (SQLException e) {
				System.out.println("closeに失敗しました");
				;	//closeの失敗は無視
			}
		}

		return loginInfo;
	}
}
