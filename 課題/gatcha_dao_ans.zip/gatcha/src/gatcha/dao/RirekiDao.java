package gatcha.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import gatcha.beans.GatchaListBeans;


public class RirekiDao extends DaoBase {

	/**
	 * 履歴テーブルに履歴データを保存する
	 *
	 * @param img
	 * @param reality
	 * @param mail
	 */
	public void insert(String img,int reality,String mail){

		if( con == null){
			//接続していない場合は何もしない
			return;
		}

		PreparedStatement stmt = null;

		try{
			///////////////////////////////////
			//SELECT文の発行
			stmt = con.prepareStatement("INSERT INTO rireki_tbl (id,img,reality,insertdate,mail) VALUES(null,?,?,NOW(),?)");

			stmt.setString(1, img);
			stmt.setInt(2, reality);
			stmt.setString(3, mail);
			stmt.executeUpdate();

		}catch(SQLException e) {
			//エラー発生した場合にコンソールにログを出力する
			e.printStackTrace();
		}
		finally {
			//接続（コネクション）を閉じる
			if(con!=null) {
				try {
					con.close();
				}
				catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}

	}

	/**
	 * 履歴データのリストを取得する
	 *
	 * @return 履歴データのリスト
	 */
	public List<GatchaListBeans> getList(){

		if( con == null){
			//接続していない場合は何もしない
			return null;
		}

		List<GatchaListBeans> list = new ArrayList<GatchaListBeans>();

		PreparedStatement stmt = null;
		ResultSet rs = null;

		try{
			///////////////////////////////////
			//SELECT文の発行
			stmt = con.prepareStatement("SELECT * FROM rireki_tbl ORDER BY insertdate DESC");

			rs = stmt.executeQuery();

			while(rs.next()){
				GatchaListBeans beans = new GatchaListBeans();

				beans.setImg(rs.getString("img"));
				beans.setReality(rs.getInt("reality"));
				beans.setInsertDate(rs.getTimestamp("insertdate"));

				list.add(beans);
			}

		}catch(SQLException e) {
			//エラー発生した場合にコンソールにログを出力する
			e.printStackTrace();
		}
		finally {
			//接続（コネクション）を閉じる
			if(con!=null) {
				try {
					con.close();
				}
				catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return list;
	}
}
