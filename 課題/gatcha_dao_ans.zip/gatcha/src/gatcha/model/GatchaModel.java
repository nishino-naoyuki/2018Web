package gatcha.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import gatcha.beans.GatchaBeans;
import gatcha.beans.GatchaListBeans;
import gatcha.beans.LoginInfoBeans;
import gatcha.dao.RirekiDao;

/**
 * ガチャに関するモデル
 * @author nishino
 *
 */
public class GatchaModel {

	/**
	 * ランダムにガチャを引く
	 *
	 * @return ガチャビーンズ
	 */
	public GatchaBeans getRandom(LoginInfoBeans loginBeans){

		///////////////////////////////
		//0～999の乱数を取得
		Random rand = new Random();

		int value = rand.nextInt(1000);

		int[] reaList =
			{0,1,2,3,4,5};
		String[] reaString =
			{"めちゃめちゃレア","かなりレア","レア","ちょっとレア","すこしレア","普通"};
		String[] imgPath =
			{"dragon.png","hippogriff.png","fox.png","hastur.png","kaiju.png","cat.png"};

		////////////////////////////
		//ビーンズのインスタンス生成
		GatchaBeans gatcha = new GatchaBeans();

		///////////////////////////
		//レア判定
		int reality = 0;
		if( value == 0 ){
			//めちゃめちゃレア
			reality = reaList[0];
		}else if( value < 20 ){
			//かなりレア
			reality = reaList[1];
		}else if( value < 100 ){
			//わりとレア
			reality = reaList[2];
		}else if( value < 200 ){
			//レア
			reality = reaList[3];
		}else if( value < 450 ){
			//ちょっとレア
			reality = reaList[4];
		}else{
			//ふつう
			reality = reaList[5];
		}
		//ビーンズに設定
		gatcha.setReality(reaList[reality]);
		gatcha.setImg(imgPath[reality]);
		gatcha.setReaString(reaString[reality]);

		////////////////////////////////
		//履歴テーブルに書き込む
		RirekiDao dao = new RirekiDao();

		try{
			///////////////////////////////////
			//DBの接続
			dao.connect();

			///////////////////////////////////
			//DBの更新
			dao.insert(gatcha.getImg(),
					gatcha.getReality(),
					loginBeans.getMail());

		}catch(Exception e) {
			//エラー発生した場合にコンソールにログを出力する
			e.printStackTrace();
		}
		finally {
			dao.close();
		}

		return gatcha;
	}

	/**
	 * 履歴のリストを取得する
	 * （日付の降順）
	 *
	 * @return 履歴リスト
	 */
	public List<GatchaListBeans> getList(){
		List<GatchaListBeans> list = new ArrayList<GatchaListBeans>();

		RirekiDao dao = new RirekiDao();

		try{
			///////////////////////////////////
			//DBの接続
			dao.connect();

			///////////////////////////////////
			//一覧の取得
			list = dao.getList();

		}catch(Exception e) {
			//エラー発生した場合にコンソールにログを出力する
			e.printStackTrace();
		}
		finally {
			//接続（コネクション）を閉じる
			dao.close();
		}

		return list;
	}
}
