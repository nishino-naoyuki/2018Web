package gatcha.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import gatcha.beans.LoginInfoBeans;
import gatcha.model.LoginModel;

@WebServlet("/auth")
public class LoginServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		///////////////////////////////////////////
		//JSPからメールアドレスとパスワードを取得
		String mail = request.getParameter("mail");
		String password = request.getParameter("password");

		///////////////////////////////////////////
		//Modelを呼び出しDBの値をメール、パスワードを照合する
		LoginModel loginModel = new LoginModel();

		LoginInfoBeans loginInfo = loginModel.login(mail, password);

		if( loginInfo != null ){
			///////////////////////////////////////////
			//ログイン結果をセッションに保存する
			HttpSession session = request.getSession(true);

			session.setAttribute("loginInfo", loginInfo);
		}else{
			//ログイン結果がnullの場合はログイン画面に戻す
			response.sendRedirect("login");
			return;
		}

		///////////////////////////////////////////
		//画面を転送する（リダイレクト）
		response.sendRedirect("top");
	}
}
