package webpool.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import webpool.beans.MemberDto;
import webpool.model.MemberModel;

@WebServlet("/list")
public class DisplayList extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		//////////////////////
		//DBへ値をセット
		MemberModel model = new MemberModel();

		List<MemberDto> list = model.getList();

		//////////////////////
		//リストをセットする
		request.setAttribute("list", list);

		RequestDispatcher dispatcher = request.getRequestDispatcher("WEB-INF/jsp/list.jsp");
		dispatcher.forward(request, response);
	}
}
