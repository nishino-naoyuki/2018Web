package webpool.beans;

import java.io.Serializable;

/**
 * メンバー情報DTO
 *
 * @author nishino
 *
 */
public class MemberDto implements Serializable{

	private String name;
	private String mail;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}


}
