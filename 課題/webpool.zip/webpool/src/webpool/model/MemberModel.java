package webpool.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import webpool.beans.MemberDto;

public class MemberModel {

	/**
	 * メンバーリストの取得
	 *
	 * @return
	 */
	public List<MemberDto> getList(){

		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		InitialContext context = null;
		List<MemberDto> list = new ArrayList<MemberDto>();

		try{
			///////////////////////////////////
			//DBの接続
//			Class.forName("com.mysql.cj.jdbc.Driver");
//
//			con = DriverManager.getConnection(
//					"jdbc:mysql://localhost:3306/webtestdb?characterEncoding=UTF-8&serverTimezone=JST",
//					"root","password");
			String resourceName = "jdbc/MySQL";
			String jndi = "java:comp/env/"+resourceName;

			context = new InitialContext();

			DataSource dataSource = (DataSource) context.lookup(jndi);

			con = dataSource.getConnection();

			///////////////////////////////////
			//SELECT文の発行
			stmt = con.prepareStatement("SELECT * FROM user_tbl");

			rs = stmt.executeQuery();

			///////////////////////////////////
			//DBから値を取得
			while( rs.next() ){
				MemberDto member = new MemberDto();

				member.setMail(rs.getString("mail"));
				member.setName(rs.getString("name"));

				list.add(member);
			}

		}catch(SQLException e) {
			//エラー発生した場合にコンソールにログを出力する
			e.printStackTrace();
		} catch (NamingException e) {
			//エラー発生した場合にコンソールにログを出力する
			e.printStackTrace();
		}
		finally {
			//接続（コネクション）を閉じる
			if(con!=null) {
				try {
					con.close();
				}
				catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return list;
	}


	/**
	 * 指定されたメールアドレスをDBから検索する
	 *
	 * @param（引数） mail メールアドレス
	 * @return メールアドレスがあった場合はtrue、無ければfalse
	 */
	public boolean findByMail(String mail){
		boolean result = false;
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;

		try{
			///////////////////////////////////
			//DBの接続
			Class.forName("com.mysql.cj.jdbc.Driver");

			con = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/webtestdb?characterEncoding=UTF-8&serverTimezone=JST",
					"root","password");

			///////////////////////////////////
			//SELECT文の発行
			stmt = con.prepareStatement("SELECT * FROM user_tbl WHERE mail=?");

			stmt.setString(1, mail);
			rs = stmt.executeQuery();

			///////////////////////////////////
			//DBから値を取得
			while( rs.next() ){
				result = true;
			}

		}catch(ClassNotFoundException e) {
			//エラー発生した場合にコンソールにログを出力する
			e.printStackTrace();
		}catch(SQLException e) {
			//エラー発生した場合にコンソールにログを出力する
			e.printStackTrace();
		}
		finally {
			//接続（コネクション）を閉じる
			if(con!=null) {
				try {
					con.close();
				}
				catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return result;
	}
}
