package mvcKadai1.beans;

import java.io.Serializable;

public class BmiBeans implements Serializable {
	private String name;
	private Integer weight;
	private Integer tall;
	private Double bmi;
	private String Message;
	/**
	 * @return name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name セットする name
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return weight
	 */
	public Integer getWeight() {
		return weight;
	}
	/**
	 * @param weight セットする weight
	 */
	public void setWeight(Integer weight) {
		this.weight = weight;
	}
	/**
	 * @return tall
	 */
	public Integer getTall() {
		return tall;
	}
	/**
	 * @param tall セットする tall
	 */
	public void setTall(Integer tall) {
		this.tall = tall;
	}
	/**
	 * @return bmi
	 */
	public Double getBmi() {
		return bmi;
	}
	/**
	 * @param bmi セットする bmi
	 */
	public void setBmi(Double bmi) {
		this.bmi = bmi;
	}
	/**
	 * @return message
	 */
	public String getMessage() {
		return Message;
	}
	/**
	 * @param message セットする message
	 */
	public void setMessage(String message) {
		Message = message;
	}


}
