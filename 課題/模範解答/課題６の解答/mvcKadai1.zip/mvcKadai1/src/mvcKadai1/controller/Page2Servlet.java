package mvcKadai1.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import mvcKadai1.beans.BmiBeans;
import mvcKadai1.model.BmiModel;

@WebServlet("/q1page2")
public class Page2Servlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
						throws ServletException, IOException {

		///////////////////////////
		//パラメータの取得
		String name = request.getParameter("name");
		String weight = request.getParameter("weight");
		String tall = request.getParameter("tall");

		///////////////////////////
		//文字列→数値変換
		BmiBeans bmiBeans = new BmiBeans();
		try{
			bmiBeans.setName(name);
			bmiBeans.setWeight(Integer.parseInt(weight));
			bmiBeans.setTall(Integer.parseInt(tall));
		}catch(Exception e){
			//エラー発生
			request.setAttribute("error", "数値を入力してください");
			RequestDispatcher dispatcher = request.getRequestDispatcher("WEB-INF/jsp/q1page1.jsp");
			dispatcher.forward(request, response);
			return;
		}

		///////////////////////////
		//モデル呼び出し
		BmiModel bmiModel = new BmiModel();

		bmiBeans = bmiModel.calculate(bmiBeans);

		///////////////////////////
		//リクエストにセット
		request.setAttribute("bmiBeans", bmiBeans);

		///////////////////////////
		//転送
		RequestDispatcher dispatcher = request.getRequestDispatcher("WEB-INF/jsp/q1page2.jsp");
		dispatcher.forward(request, response);
	}

}
