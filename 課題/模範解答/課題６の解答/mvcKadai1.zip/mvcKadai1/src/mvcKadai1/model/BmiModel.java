/**
 *
 */
package mvcKadai1.model;

import mvcKadai1.beans.BmiBeans;

/**
 * @author nishino
 *
 */
public class BmiModel {

	/**
	 * BMIを計算する
	 *
	 * @param bmiBeans
	 * @return
	 */
	public BmiBeans calculate(BmiBeans bmiBeans){

		//BMIを計算
		double wk = bmiBeans.getTall()/100.0;
		double bmi = (double)bmiBeans.getWeight()/(double)(wk*wk);

		//メッセージを取得
		String message = "";

		if( bmi < 16.0 ){
			message = "痩せすぎ";
		}else if( bmi < 17.0 ){
			message = "痩せ";
		}else if( bmi < 18.5 ){
			message = "痩せぎみ";
		}else if( bmi < 25.0 ){
			message = "標準";
		}else if( bmi < 30.0 ){
			message = "過体重";
		}else if( bmi < 35.0 ){
			message = "肥満（１度）";
		}else if( bmi < 40.0 ){
			message = "肥満（２度）";
		}else{
			message = "肥満（３度）";
		}

		//ビーンにセット
		bmiBeans.setBmi(bmi);
		bmiBeans.setMessage(message);

		return bmiBeans;
	}
}
