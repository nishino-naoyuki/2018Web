package gatcha.beans;

import java.io.Serializable;

/**
 * ガチャ情報を表すビーンズ
 * @author nishino
 *
 */
public class GatchaBeans implements Serializable {

	private String img;
	private int reality;
	private String reaString;

	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	public int getReality() {
		return reality;
	}
	public void setReality(int reality) {
		this.reality = reality;
	}
	public String getReaString() {
		return reaString;
	}
	public void setReaString(String reaString) {
		this.reaString = reaString;
	}

}
