package gatcha.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import gatcha.beans.GatchaListBeans;
import gatcha.model.GatchaModel;

@WebServlet("/list")
public class DispGatchaListServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		//////////////////////////////
		//リストを取得
		GatchaModel model = new GatchaModel();

		List<GatchaListBeans> list = model.getList();

		/////////////////////////////
		//リクエストにセット
		request.setAttribute("list", list);

		RequestDispatcher dispatcher = request.getRequestDispatcher("WEB-INF/jsp/list.jsp");
		dispatcher.forward(request, response);
	}
}
