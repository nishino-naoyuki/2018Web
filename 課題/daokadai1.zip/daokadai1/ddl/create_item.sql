
/* Create Tables */

CREATE TABLE item_tbl
(
	-- 商品の識別ID
	-- 自動採番
	item_id int NOT NULL AUTO_INCREMENT COMMENT '商品の識別ID
自動採番',
	-- 商品名
	name varchar(200) NOT NULL COMMENT '商品名',
	-- 商品の値段
	price int NOT NULL COMMENT '商品の値段',
	PRIMARY KEY (item_id)
);

insert into item_tbl(item_id,name,price) value(null,'フルーチェ（いちご味）',120);
insert into item_tbl(item_id,name,price) value(null,'フルーチェ（メロン味）',120);
insert into item_tbl(item_id,name,price) value(null,'フルーチェ（マンゴー味）',120);
insert into item_tbl(item_id,name,price) value(null,'エアリアル',100);