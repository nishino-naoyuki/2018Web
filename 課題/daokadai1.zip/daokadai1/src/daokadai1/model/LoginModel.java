package daokadai1.model;

import daokadai1.beans.LoginInfoBeans;

public class LoginModel {

	/**
	 * ログイン処理を行う
	 *
	 * @param mail
	 * @param password
	 * @return null→ログイン失敗/非null→ログイン成功
	 */
	public LoginInfoBeans login(String mail,String password){

		LoginInfoBeans login = null;

		/////////////////////////////////////
		//ここでDAOを呼び出して正しい
		//メールアドレスとパスワードかをチェックする


		//////////////////////////////////////
		//【注意】↓のコードはとりあえず動くようにいれたダミーコードです。後で消してね！by先輩
		login = new LoginInfoBeans();

		login.setMail("dummy@mail");
		login.setName("ダミー");

		return login;
	}
}
