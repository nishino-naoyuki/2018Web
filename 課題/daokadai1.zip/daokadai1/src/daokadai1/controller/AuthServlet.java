package daokadai1.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import daokadai1.beans.LoginInfoBeans;
import daokadai1.model.LoginModel;

@WebServlet("/auth")
public class AuthServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
												throws ServletException, IOException {

		///////////////////////////////////////////
		//ユーザー名とパスワードを取得
		String mail = request.getParameter("mail");
		String password = request.getParameter("password");

		//////////////////////////////////////////
		//モデルを呼び出してログイン処理を行う
		LoginModel loginModel = new LoginModel();

		LoginInfoBeans loginInfo = loginModel.login(mail, password);

		///////////////////////////////////////////
		//ログインに成功した場合は、セッションにログイン情報を保存する
		if( loginInfo != null ){
			HttpSession session = request.getSession();
			session.setAttribute("loginInfo", loginInfo);
		}else{
			response.sendRedirect("login");
			return;
		}

		///////////////////////////////////////////
		//画面を転送する（リダイレクト）
		response.sendRedirect("dushboad");
	}
}
