package daokadai1.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/insertuser")
public class InsertUserServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
												throws ServletException, IOException {

		///////////////////////////////////////////
		//値の取得

		//////////////////////////////////////////
		//入力チェックを行う

		//////////////////////////////////////////
		//モデルを呼び出して登録処理を行う

		///////////////////////////////////////////
		//画面を転送する（リダイレクト）
		response.sendRedirect("completeuser");
	}
}
