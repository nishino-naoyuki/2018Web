package daokadai1.dao;

/**
 * 商品テーブルのDAO
 *
 * @author nishino
 *
 */
public class ItemDao {

	/////////////////////////////////////
	//検索するメソッドが必要だお思うよ。
	//
	//検索は、引数なしで商品テーブルを全件取得してItemBeansの
	//リストを返すようなメソッドでいいんじゃないかな
	// by 先輩
}
