package daokadai1.dao;

/**
 * DAOの基本クラス
 *
 * @author nishino
 *
 */
public class DaoBase {

}
